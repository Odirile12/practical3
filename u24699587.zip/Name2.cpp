#include "Name2.h"
#include "sendMessageCommand.h"
#include "saveMessageCommand.h"
#include "ChatRoom.h"
#include <iostream>
#include <thread>
#include <chrono>

Name2::Name2() : User("Bob") {
    std::cout << "Name2 user created: Bob" << std::endl;
}

void Name2::send(const std::string& message, ChatRoom* room) {
    if (!isInRoom(room)) {
        std::cout << "Error: " << name << " is not in " << room->getName() << "!" << std::endl;
        return;
    }
    
    if (message.empty()) {
        std::cout << "Error: " << name << " cannot send empty message!" << std::endl;
        return;
    }
    
    std::cout << name << " is sending message to " << room->getName() << ": " << message << std::endl;
    
    Command* sendCmd = new sendMessageCommand(room, this, message);
    Command* saveCmd = new SaveMessageCommand(room, this, message);
    
    addCommand(sendCmd);
    addCommand(saveCmd);
    executeCommands();
}

void Name2::receive(const std::string& message, User* fromUser, ChatRoom* room) {
    std::cout << "💬 [" << room->getName() << "] " << name << " received from " 
              << fromUser->getName() << ": " << message << std::endl;
}

void Name2::sendDelayedMessage(const std::string& message, ChatRoom* room, int delaySeconds) {
    std::cout << "⏰ " << name << " scheduling message in " << delaySeconds << " seconds..." << std::endl;
    
    // Simulate delay (in real implementation, you'd use proper scheduling)
    if (delaySeconds > 0) {
        std::this_thread::sleep_for(std::chrono::seconds(delaySeconds));
    }
    
    send("🚀 [DELAYED] " + message, room);
}